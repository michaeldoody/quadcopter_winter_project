import serial
import io
ser = serial.Serial('/dev/ttyACM2', timeout=1)  # open serial port
ser.port         # check which port was really used
ser.reset_input_buffer()
ser.reset_output_buffer()
ser.write(b'hello')     # write a string
ser.read(100)
ser.close()             # close port
